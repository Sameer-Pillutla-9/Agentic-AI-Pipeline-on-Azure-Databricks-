# Agentic Databricks ML Pipeline

Minimal example of an agent-style ML pipeline for shipments:

- Loads CSV shipments into a Pandas DataFrame
- Runs through simple "agents" (data, feature, model, report)
- Writes a summary CSV for BI dashboards

This is designed so you can later port it into Azure Databricks notebooks
and replace Pandas with PySpark + Delta Lake.
