# Simple agentic ML pipeline demo (local, Pandas-based).
import os
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

class Context(dict):
    pass

class DataAgent:
    def run(self, ctx: Context):
        path = ctx.get("raw_csv", "./data/sample_shipments.csv")
        df = pd.read_csv(path)
        ctx["df"] = df
        print(f"[DataAgent] Loaded {len(df)} rows")
        return ctx

class FeatureAgent:
    def run(self, ctx: Context):
        df = ctx["df"].copy()
        df["delay_days"] = df["actual_days"] - df["expected_days"]
        df["is_express"] = (df["priority"] == "EXPRESS").astype(int)
        ctx["features_df"] = df
        print("[FeatureAgent] Engineered delay_days and is_express")
        return ctx

class ModelAgent:
    def run(self, ctx: Context):
        df = ctx["features_df"]
        X = df[["expected_days", "weight_kg", "is_express"]]
        y = df["delay_days"]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        model = RandomForestRegressor(n_estimators=50, random_state=42)
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        mae = mean_absolute_error(y_test, preds)
        ctx["model"] = model
        ctx["mae"] = mae
        print(f"[ModelAgent] MAE={mae:.4f}")
        return ctx

class ReportAgent:
    def run(self, ctx: Context):
        os.makedirs("reports", exist_ok=True)
        summary = pd.DataFrame(
            [{
                "mae": ctx.get("mae"),
                "rows": len(ctx["features_df"])
            }]
        )
        out_path = "reports/model_summary.csv"
        summary.to_csv(out_path, index=False)
        print(f"[ReportAgent] Wrote {out_path}")
        return ctx

def main():
    ctx = Context(raw_csv="./data/sample_shipments.csv")
    pipeline = [DataAgent(), FeatureAgent(), ModelAgent(), ReportAgent()]
    for agent in pipeline:
        ctx = agent.run(ctx)

if __name__ == "__main__":
    main()
