import pandas as pd
import numpy as np

def bayes_beta_bernoulli(csv_path: str = "data/ab_experiment_sample.csv", n_samples: int = 50000):
    df = pd.read_csv(csv_path)
    a = df[df['variant'] == 'A']['converted']
    b = df[df['variant'] == 'B']['converted']

    alpha_a = 1 + a.sum()
    beta_a = 1 + (len(a) - a.sum())
    alpha_b = 1 + b.sum()
    beta_b = 1 + (len(b) - b.sum())

    samples_a = np.random.beta(alpha_a, beta_a, size=n_samples)
    samples_b = np.random.beta(alpha_b, beta_b, size=n_samples)
    prob_b_better = float((samples_b > samples_a).mean())
    print(f"P(B > A) ≈ {prob_b_better:.3f}")
    return prob_b_better

if __name__ == "__main__":
    bayes_beta_bernoulli()
