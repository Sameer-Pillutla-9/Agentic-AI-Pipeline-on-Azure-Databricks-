import pandas as pd
from scipy import stats

def two_prop_ztest(csv_path: str = "data/ab_experiment_sample.csv"):
    df = pd.read_csv(csv_path)
    a = df[df['variant'] == 'A']['converted']
    b = df[df['variant'] == 'B']['converted']

    p1 = a.mean()
    p2 = b.mean()
    n1 = len(a)
    n2 = len(b)
    p_pool = (a.sum() + b.sum()) / float(n1 + n2)
    se = (p_pool * (1 - p_pool) * (1/n1 + 1/n2)) ** 0.5
    z = (p2 - p1) / se
    p_val = 2 * (1 - stats.norm.cdf(abs(z)))
    print(f"A: {p1:.3f}, n={n1}; B: {p2:.3f}, n={n2}")
    print(f"z={z:.3f}, p-value={p_val:.4f}")
    return z, p_val

if __name__ == "__main__":
    two_prop_ztest()
