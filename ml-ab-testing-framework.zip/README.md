# ML A/B Testing Framework

Implements:

- Frequentist two-proportion z-test
- Bayesian Beta-Bernoulli posterior comparison
- Bootstrap confidence interval for lift
