# Databricks ML CI/CD (Azure DevOps Skeleton)

This repo contains a minimal CI/CD pipeline:

- Install dependencies
- Run pytest unit tests
- (Placeholder) call Databricks CLI to trigger a job
