import notebooks.train_model as tm

def test_train_runs():
    mae = tm.train()
    assert mae > 0
